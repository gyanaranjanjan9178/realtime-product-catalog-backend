
module.exports = {
  development: {
    username: 'postgres',
    password: 'Abhimanyau9178',
    database: 'catalog_app',
    host: '127.0.0.1',
    dialect: 'postgres'
  },
  test: {
    username: 'postgres',
    password: 'Abhimanyau9178',
    database: 'catalog_app_test',
    host: '127.0.0.1',
    dialect: 'postgres'
  },
  production: {
    username: 'postgres',
    password: 'Abhimanyau9178',
    database: 'catalog_app_prod',
    host: '127.0.0.1',
    dialect: 'postgres'
  }
};

